﻿namespace FSE.SkillTracker.AddProfileApi
{
    public class CosmosDbSettings
    {
        public string DatabaseName { get; set; }

        public string Account { get; set; }

        public string Key { get; set; }
    }
}
