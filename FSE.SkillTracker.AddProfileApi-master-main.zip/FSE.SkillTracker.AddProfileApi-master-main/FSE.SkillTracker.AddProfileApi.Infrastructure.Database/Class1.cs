﻿namespace FSE.SkillTracker.AddProfileApi.Infrastructure.Database
{
    public class Class1
    {

    }
}