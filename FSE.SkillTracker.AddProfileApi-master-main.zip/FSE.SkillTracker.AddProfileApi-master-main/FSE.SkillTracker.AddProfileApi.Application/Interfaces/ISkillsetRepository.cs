﻿using FSE.SkillTracker.AddProfileApi.Domain.Entities;

namespace FSE.SkillTracker.AddProfileApi.Application.Interfaces
{
    public interface ISkillsetRepository : IRepository<TechnicalSkills>
    {
    }
}
