﻿using FSE.SkillTracker.AddProfileApi.Domain.Entities;

namespace FSE.SkillTracker.AddProfileApi.Application.Interfaces
{
    public interface IProfileRepository : IRepository<Profile>
    {
    }
}
