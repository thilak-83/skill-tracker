﻿namespace FSE.SkillTracker.AddProfileApi.Domain.Entities
{
    public class TechnicalSkills : EntityKey
    {
        public string Name { get; set; }
    }
}
