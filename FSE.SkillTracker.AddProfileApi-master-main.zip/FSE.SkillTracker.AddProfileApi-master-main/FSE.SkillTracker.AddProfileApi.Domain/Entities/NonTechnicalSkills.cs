﻿namespace FSE.SkillTracker.AddProfileApi.Domain.Entities
{
    public class NonTechnicalSkills : EntityKey
    {
        public string Name { get; set; }
    }
}
